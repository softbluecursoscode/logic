#!/bin/bash

java -jar softblue-logic.jar

